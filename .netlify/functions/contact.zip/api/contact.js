// api/contact.js
var fs = require("fs");
var path = require("path");
module.exports = async (req, res) => {
  res.setHeader("Access-Control-Allow-Credentials", true);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS,PATCH,DELETE,POST,PUT");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version"
  );
  if (req.method === "OPTIONS") {
    res.status(200).end();
    return;
  }
  if (req.method !== "POST") {
    return res.status(405).json({
      success: false,
      error: "Method not allowed"
    });
  }
  try {
    const { name, email, phone, organization, service, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        error: "Name, email, and message are required fields"
      });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        error: "Invalid email address"
      });
    }
    const contactData = {
      id: Date.now(),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone ? phone.trim() : null,
      organization: organization ? organization.trim() : null,
      service: service || null,
      message: message.trim(),
      submitted_at: (/* @__PURE__ */ new Date()).toISOString(),
      ip_address: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
      user_agent: req.headers["user-agent"]
    };
    console.log("\u{1F4E7} New contact submission:", {
      name: contactData.name,
      email: contactData.email,
      timestamp: contactData.submitted_at
    });
    res.status(200).json({
      success: true,
      message: "Thank you for contacting us! We will get back to you soon.",
      contactId: contactData.id
    });
  } catch (error) {
    console.error("\u274C Error processing contact form:", error);
    res.status(500).json({
      success: false,
      error: "An error occurred while processing your request. Please try again later."
    });
  }
};
